"use client";

import { useMemo, useState } from "react";
import {
  AlertTriangle, ArrowRight, BarChart3, Bell, CheckCircle2, ChevronRight,
  CircleHelp, Clock3, Crosshair, Droplets, Flame, Info, Layers3, MapPin,
  Menu, Navigation, Package, Radio, RefreshCw, ShieldCheck, Siren, Truck,
  Upload, Users, Waves, X, Zap
} from "lucide-react";

type Incident = {
  id:string; type:string; location:string; priority:number; affected:number;
  status:string; confidence:number; danger:boolean; reason:string; x:number; y:number; time:string;
};

const demoIncidents:Incident[] = [
  {id:"DL-1042",type:"Flood",location:"Riverside Area",priority:96,affected:240,status:"Awaiting response",confidence:94,danger:true,reason:"Large affected population, immediate danger, and limited road access.",x:27,y:35,time:"10:42 PM"},
  {id:"DL-1047",type:"Building damage",location:"Central District",priority:89,affected:65,status:"Team assigned",confidence:88,danger:true,reason:"Structural damage combined with reported people trapped nearby.",x:55,y:28,time:"10:51 PM"},
  {id:"DL-1039",type:"Road blockage",location:"Highway Zone",priority:72,affected:30,status:"Needs verification",confidence:76,danger:false,reason:"Blocked access may delay emergency movement to nearby incidents.",x:72,y:62,time:"10:35 PM"},
  {id:"DL-1044",type:"Fire",location:"Market Quarter",priority:78,affected:48,status:"Response en route",confidence:91,danger:true,reason:"Active fire report with high confidence and dense occupancy.",x:43,y:66,time:"10:46 PM"},
  {id:"DL-1049",type:"Landslide",location:"North Ridge",priority:67,affected:18,status:"Needs verification",confidence:71,danger:false,reason:"Access is constrained and the report needs corroboration.",x:79,y:31,time:"11:02 PM"}
];

const baseResources = [
  ["Rescue teams",8,"2 assigned"],["Ambulances",5,"1 assigned"],["Food supplies",420,"120 allocated"],
  ["Water",780,"240 allocated"],["Medical kits",64,"18 allocated"],["Rescue boats",3,"1 assigned"]
];

function scoreReport(r:{affected:number,danger:boolean,type:string,description:string}) {
  const infrastructure = /bridge|road|building|blocked|damage|collapse/i.test(r.description) ? 18 : 7;
  const access = /blocked|isolated|cut off|water/i.test(r.description) ? 15 : 7;
  const typeBoost:{[k:string]:number} = {Flood:10,Fire:12,Earthquake:15,Cyclone:13,Landslide:14,"Building damage":14,"Road blockage":6,Other:4};
  const score = Math.min(100, Math.round(
    25 + Math.min(28, r.affected / 10) + (r.danger ? 20 : 0) + infrastructure + access + (typeBoost[r.type] ?? 4)
  ));
  return score;
}

function priorityLabel(p:number){return p>=90?"CRITICAL":p>=75?"HIGH":p>=50?"MEDIUM":"LOW"}
function priorityClass(p:number){return p>=90?"text-red-300 bg-red-500/10 border-red-400/20":p>=75?"text-orange-300 bg-orange-500/10 border-orange-400/20":p>=50?"text-yellow-200 bg-yellow-500/10 border-yellow-400/20":"text-emerald-300 bg-emerald-500/10 border-emerald-400/20"}

export default function Home(){
  const [incidents,setIncidents]=useState<Incident[]>([]);
  const [selected,setSelected]=useState<Incident|null>(null);
  const [demo,setDemo]=useState(false);
  const [page,setPage]=useState<"home"|"dashboard"|"report"|"how">("home");
  const [toast,setToast]=useState("");
  const [mobile,setMobile]=useState(false);
  const [form,setForm]=useState({type:"Flood",location:"",description:"",affected:"20",danger:"Yes"});
  const [analyzing,setAnalyzing]=useState(false);
  const [resources,setResources]=useState(baseResources.map(x=>[...x] as [string,number,string]));
  const data = demo ? demoIncidents : incidents;
  const sorted=useMemo(()=>[...data].sort((a,b)=>b.priority-a.priority),[data]);
  const affected=data.reduce((a,b)=>a+b.affected,0);
  const critical=data.filter(x=>x.priority>=90).length;

  function launchDemo(){
    setDemo(true); setPage("dashboard"); setSelected(null); setToast("Demo mode launched — live incident feed populated.");
    setTimeout(()=>setToast(""),3500);
  }
  function submitReport(){
    setAnalyzing(true);
    setTimeout(()=>{
      const affected=Number(form.affected)||0;
      const score=scoreReport({affected,danger:form.danger==="Yes",type:form.type,description:form.description});
      const id=`DL-${1050+incidents.length}`;
      const inc:Incident={id,type:form.type,location:form.location||"Unspecified location",priority:score,affected,
        status:"Awaiting response",confidence:89,danger:form.danger==="Yes",
        reason: score>=90 ? "High population impact and immediate danger require rapid response." : "Priority reflects reported impact, danger level, access constraints, and report confidence.",
        x:30+Math.random()*55,y:25+Math.random()*50,time:"Just now"};
      setIncidents(v=>[inc,...v]); setSelected(inc); setAnalyzing(false); setPage("dashboard");
      setToast(`Report ${id} analyzed — priority ${score}/100`);
      setTimeout(()=>setToast(""),4000);
    },1500);
  }

  const nav=(p:"home"|"dashboard"|"report"|"how")=>{setPage(p);setMobile(false);};

  return <main className="min-h-screen grid-bg">
    <header className="sticky top-0 z-40 border-b border-white/10 bg-[#071013]/85 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-5 h-16 flex items-center justify-between">
        <button onClick={()=>nav("home")} className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-xl bg-teal-400/10 border border-teal-300/20 flex items-center justify-center"><Crosshair className="text-teal-300" size={20}/></div>
          <div className="font-bold tracking-tight">Disaster<span className="text-teal-300">Lens</span><div className="text-[9px] uppercase tracking-[.25em] text-slate-500">Emergency intelligence</div></div>
        </button>
        <nav className="hidden md:flex items-center gap-1 text-sm text-slate-300">
          {([["dashboard","Live Dashboard"],["report","Report Emergency"],["how","How it works"]] as const).map(([p,l])=><button key={p} onClick={()=>nav(p)} className={`px-4 py-2 rounded-lg hover:bg-white/5 ${page===p?"bg-white/5 text-white":""}`}>{l}</button>)}
        </nav>
        <div className="flex items-center gap-2">
          <button onClick={launchDemo} className="hidden sm:flex items-center gap-2 rounded-lg bg-teal-400 text-slate-950 font-semibold px-4 py-2 text-sm hover:bg-teal-300"><Zap size={16}/> Launch Demo</button>
          <button onClick={()=>setMobile(!mobile)} className="md:hidden p-2 rounded-lg hover:bg-white/5"><Menu size={20}/></button>
        </div>
      </div>
      {mobile&&<div className="md:hidden border-t border-white/10 p-3 flex flex-col gap-1">
        <button onClick={()=>nav("dashboard")} className="text-left p-3 rounded-lg hover:bg-white/5">Live Dashboard</button>
        <button onClick={()=>nav("report")} className="text-left p-3 rounded-lg hover:bg-white/5">Report Emergency</button>
        <button onClick={()=>nav("how")} className="text-left p-3 rounded-lg hover:bg-white/5">How it works</button>
        <button onClick={launchDemo} className="p-3 rounded-lg bg-teal-400 text-slate-950 font-semibold">Launch Demo</button>
      </div>}
    </header>

    {toast&&<div className="fixed top-20 right-5 z-50 card px-4 py-3 text-sm flex items-center gap-2"><CheckCircle2 size={16} className="text-teal-300"/>{toast}</div>}

    {page==="home"&&<Landing nav={nav} launchDemo={launchDemo}/>}
    {page==="report"&&<Report form={form} setForm={setForm} analyzing={analyzing} submit={submitReport}/>}
    {page==="dashboard"&&<Dashboard data={data} sorted={sorted} affected={affected} critical={critical} selected={selected} setSelected={setSelected} resources={resources} setResources={setResources} demo={demo} launchDemo={launchDemo}/>}
    {page==="how"&&<How/>}

    <footer className="max-w-7xl mx-auto px-5 py-10 text-xs text-slate-500 flex flex-col sm:flex-row justify-between gap-3 border-t border-white/5 mt-12">
      <span>© 2026 DisasterLens · Hackathon prototype</span>
      <span className="flex items-center gap-1"><ShieldCheck size={14}/> Decision support — not an autonomous emergency authority.</span>
    </footer>
  </main>
}

function Landing({nav,launchDemo}:{nav:(p:any)=>void,launchDemo:()=>void}){
 return <section className="max-w-7xl mx-auto px-5 pt-20 pb-10">
  <div className="grid lg:grid-cols-[1.1fr_.9fr] gap-10 items-center">
   <div>
    <div className="inline-flex items-center gap-2 rounded-full border border-teal-300/20 bg-teal-300/5 px-3 py-1 text-xs text-teal-200"><Radio size={13}/> LIVE-READY RESPONSE INTELLIGENCE</div>
    <h1 className="mt-6 text-5xl sm:text-7xl font-black tracking-[-.05em] leading-[.95]">See the crisis.<br/><span className="text-teal-300">Prioritize</span> the response.</h1>
    <p className="mt-6 text-lg text-slate-400 max-w-xl">AI-powered disaster intelligence that transforms community reports into actionable emergency insights.</p>
    <div className="mt-8 flex flex-wrap gap-3">
      <button onClick={()=>nav("report")} className="px-5 py-3 rounded-xl bg-white text-slate-950 font-bold flex items-center gap-2 hover:bg-slate-200">Report an Emergency <ArrowRight size={17}/></button>
      <button onClick={()=>nav("dashboard")} className="px-5 py-3 rounded-xl border border-white/10 bg-white/5 font-semibold flex items-center gap-2 hover:bg-white/10">Open Live Dashboard</button>
    </div>
    <div className="mt-10 grid grid-cols-3 gap-3 max-w-lg">
      {[["0–100","priority scoring"],["6","resource types"],["24/7","dashboard-ready"]].map(([a,b])=><div className="card p-4" key={a}><div className="text-xl font-bold">{a}</div><div className="text-xs text-slate-500 mt-1">{b}</div></div>)}
    </div>
   </div>
   <div className="relative">
    <div className="card p-4 overflow-hidden">
      <div className="h-[430px] rounded-xl bg-[#0a171a] relative overflow-hidden">
        <div className="absolute inset-0 opacity-50" style={{backgroundImage:"radial-gradient(circle at 30% 35%, rgba(45,212,191,.22), transparent 24%), radial-gradient(circle at 72% 55%, rgba(248,113,113,.18), transparent 20%)"}}/>
        <div className="absolute inset-0 opacity-20" style={{backgroundImage:"linear-gradient(rgba(148,163,184,.2) 1px, transparent 1px),linear-gradient(90deg,rgba(148,163,184,.2) 1px,transparent 1px)",backgroundSize:"42px 42px"}}/>
        {[["27","34","96","red"],["55","28","89","orange"],["72","62","72","yellow"],["43","66","78","orange"]].map(([x,y,p,c])=><button key={p} onClick={launchDemo} style={{left:x+"%",top:y+"%"}} className={`absolute -translate-x-1/2 -translate-y-1/2 h-11 w-11 rounded-full border-4 border-[#0a171a] ${c==="red"?"bg-red-400":"bg-orange-400"} shadow-lg flex items-center justify-center font-black text-[10px] text-slate-950`}>{p}</button>)}
        <div className="absolute left-4 top-4 rounded-lg bg-black/50 border border-white/10 px-3 py-2 text-xs text-slate-300"><span className="text-teal-300">●</span> Simulated operations map</div>
        <div className="absolute left-4 right-4 bottom-4 card p-4 flex items-center justify-between">
          <div><div className="text-xs text-slate-500">HIGHEST PRIORITY</div><div className="font-bold">Riverside Flood Zone</div><div className="text-xs text-slate-400">240 people potentially affected</div></div>
          <div className="text-3xl font-black text-red-300">96<span className="text-sm text-slate-500">/100</span></div>
        </div>
      </div>
    </div>
   </div>
  </div>
  <div className="mt-20">
   <div className="text-xs uppercase tracking-[.2em] text-slate-500">Built for the first 3 minutes</div>
   <div className="grid md:grid-cols-3 gap-4 mt-4">
    {[
      ["01","Turn noise into signal","Aggregate reports and surface the incidents that deserve attention first.",Siren],
      ["02","Explain every score","Show the factors behind each priority so responders can review the recommendation.",BarChart3],
      ["03","Coordinate resources","Pair ranked incidents with a simple resource allocation view.",Truck]
    ].map(([n,t,d,I]:any)=><div className="card p-6" key={n}><div className="text-teal-300 font-mono text-xs">{n}</div><I className="mt-5 text-slate-300" size={21}/><h3 className="mt-4 font-bold text-lg">{t}</h3><p className="mt-2 text-sm text-slate-400 leading-6">{d}</p></div>)}
   </div>
  </div>
 </section>
}

function Report({form,setForm,analyzing,submit}:{form:any,setForm:any,analyzing:boolean,submit:()=>void}){
 return <section className="max-w-5xl mx-auto px-5 pt-12">
  <div className="mb-8"><div className="text-xs uppercase tracking-[.2em] text-teal-300">Community intake</div><h2 className="text-4xl font-black mt-2">Report an emergency</h2><p className="text-slate-400 mt-2">Keep it factual and concise. The result is decision-support information for trained responders.</p></div>
  <div className="grid lg:grid-cols-[1fr_.65fr] gap-5">
   <div className="card p-6 space-y-5">
    <div><label className="text-sm text-slate-300">Disaster type</label><select value={form.type} onChange={e=>setForm({...form,type:e.target.value})} className="mt-2 w-full rounded-xl bg-black/20 border border-white/10 p-3 outline-none">{["Flood","Fire","Earthquake","Cyclone","Landslide","Road blockage","Building damage","Other"].map(x=><option key={x}>{x}</option>)}</select></div>
    <div><label className="text-sm text-slate-300">Location</label><input value={form.location} onChange={e=>setForm({...form,location:e.target.value})} placeholder="Area, landmark, city" className="mt-2 w-full rounded-xl bg-black/20 border border-white/10 p-3 outline-none"/></div>
    <div><label className="text-sm text-slate-300">Description</label><textarea value={form.description} onChange={e=>setForm({...form,description:e.target.value})} rows={5} placeholder="What happened? What access or infrastructure problems are visible?" className="mt-2 w-full rounded-xl bg-black/20 border border-white/10 p-3 outline-none resize-none"/></div>
    <div className="grid sm:grid-cols-2 gap-4">
      <div><label className="text-sm text-slate-300">People affected</label><input type="number" min="0" value={form.affected} onChange={e=>setForm({...form,affected:e.target.value})} className="mt-2 w-full rounded-xl bg-black/20 border border-white/10 p-3"/></div>
      <div><label className="text-sm text-slate-300">Immediate danger</label><div className="mt-2 flex gap-2">{["Yes","No"].map(x=><button type="button" onClick={()=>setForm({...form,danger:x})} className={`flex-1 rounded-xl p-3 border ${form.danger===x?"border-teal-300/40 bg-teal-300/10":"border-white/10 bg-black/20"}`} key={x}>{x}</button>)}</div></div>
    </div>
    <div className="grid sm:grid-cols-2 gap-3">
      <button className="rounded-xl border border-dashed border-white/15 p-4 text-sm text-slate-400 hover:bg-white/5"><Upload size={18} className="mx-auto mb-2"/>Optional photo</button>
      <button className="rounded-xl border border-dashed border-white/15 p-4 text-sm text-slate-400 hover:bg-white/5"><Upload size={18} className="mx-auto mb-2"/>Optional video</button>
    </div>
    <button onClick={submit} disabled={analyzing} className="w-full rounded-xl bg-teal-400 text-slate-950 font-black py-3.5 flex justify-center items-center gap-2 disabled:opacity-60">{analyzing?<><RefreshCw className="animate-spin" size={18}/> Analyzing report…</>:<>Submit Report <ArrowRight size={18}/></>}</button>
   </div>
   <div className="space-y-4">
    <div className="card p-5"><div className="flex items-center gap-2 text-teal-300"><Info size={17}/><span className="font-semibold">What the AI checks</span></div><div className="mt-4 space-y-3">{["Severity","People affected","Immediate danger","Infrastructure damage","Accessibility","Report confidence"].map(x=><div key={x} className="flex justify-between text-sm"><span className="text-slate-400">{x}</span><span className="text-slate-600">weighted</span></div>)}</div></div>
    <div className="card p-5"><div className="text-sm font-semibold">Safety note</div><p className="text-sm text-slate-400 mt-2 leading-6">Never put yourself in danger to collect evidence. DisasterLens is a prototype decision-support tool; emergency professionals remain responsible for final decisions.</p></div>
   </div>
  </div>
 </section>
}

function Dashboard({data,sorted,affected,critical,selected,setSelected,resources,setResources,demo,launchDemo}:{data:Incident[],sorted:Incident[],affected:number,critical:number,selected:Incident|null,setSelected:(x:Incident|null)=>void,resources:any,demo:boolean,launchDemo:()=>void}){
 const stats=[["Active incidents",data.length,AlertTriangle],["Critical incidents",critical,Siren],["People affected",affected,Users],["Areas needing assistance",new Set(data.map(x=>x.location)).size,MapPin],["Reports received",data.length+7,Radio]];
 return <section className="max-w-7xl mx-auto px-5 pt-8">
  <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4"><div><div className="text-xs uppercase tracking-[.2em] text-teal-300 flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-teal-300 animate-pulse"/> Operations center</div><h2 className="text-4xl font-black mt-2">Live emergency dashboard</h2><p className="text-slate-400 mt-2">Prioritized, explainable incident intelligence.</p></div><button onClick={launchDemo} className="px-4 py-2.5 rounded-xl border border-white/10 bg-white/5 text-sm flex items-center gap-2"><RefreshCw size={15}/> {demo?"Replay demo":"Load demo data"}</button></div>
  <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mt-7">{stats.map(([t,v,I]:any)=><div className="card p-4" key={t}><I size={17} className="text-slate-500"/><div className="text-2xl font-black mt-3">{v}</div><div className="text-xs text-slate-500 mt-1">{t}</div></div>)}</div>
  <div className="grid xl:grid-cols-[1.4fr_.8fr] gap-5 mt-5">
   <div className="card p-4">
    <div className="flex items-center justify-between mb-3"><div><h3 className="font-bold">Incident map</h3><div className="text-xs text-slate-500">Click a marker for details</div></div><div className="text-xs text-slate-500 flex gap-3"><span className="text-red-300">● Critical</span><span className="text-orange-300">● High</span><span className="text-yellow-200">● Medium</span></div></div>
    <div className="h-[470px] rounded-xl bg-[#0a171a] relative overflow-hidden border border-white/5">
      <div className="absolute inset-0 opacity-20" style={{backgroundImage:"linear-gradient(rgba(148,163,184,.2) 1px, transparent 1px),linear-gradient(90deg,rgba(148,163,184,.2) 1px,transparent 1px)",backgroundSize:"40px 40px"}}/>
      <div className="absolute inset-0 opacity-25" style={{backgroundImage:"radial-gradient(ellipse at 25% 50%, transparent 0 12%, rgba(71,85,105,.5) 12.3% 12.6%, transparent 13%),radial-gradient(ellipse at 70% 35%, transparent 0 16%, rgba(71,85,105,.5) 16.3% 16.6%, transparent 17%)"}}/>
      {data.map(i=><button key={i.id} onClick={()=>setSelected(i)} style={{left:i.x+"%",top:i.y+"%"}} className={`absolute -translate-x-1/2 -translate-y-1/2 h-12 w-12 rounded-full border-4 border-[#0a171a] shadow-lg flex items-center justify-center font-black text-[11px] text-slate-950 ${i.priority>=90?"bg-red-400":i.priority>=75?"bg-orange-400":i.priority>=50?"bg-yellow-300":"bg-emerald-400"}`}>{i.priority}</button>)}
      {!data.length&&<div className="absolute inset-0 flex items-center justify-center"><div className="text-center"><MapPin className="mx-auto text-slate-600" size={35}/><p className="mt-3 text-slate-500">No active incidents yet.</p><button onClick={launchDemo} className="mt-3 text-teal-300 text-sm">Launch demo →</button></div></div>}
      <div className="absolute left-4 bottom-4 px-3 py-2 rounded-lg bg-black/50 border border-white/10 text-xs text-slate-400">SIMULATED MAP · replace with Mapbox/Google Maps in production</div>
    </div>
   </div>
   <div className="space-y-5">
    <div className="card p-5"><div className="flex items-center justify-between"><div><h3 className="font-bold">Where should responders go first?</h3><p className="text-xs text-slate-500 mt-1">Explainable ranking</p></div><BarChart3 size={18} className="text-teal-300"/></div>
      <div className="mt-4 space-y-2">{sorted.slice(0,5).map((i,n)=><button onClick={()=>setSelected(i)} key={i.id} className="w-full text-left rounded-xl p-3 bg-white/[.03] border border-white/5 hover:bg-white/[.06]"><div className="flex gap-3"><div className="text-xs text-slate-600 pt-1 w-4">{n+1}</div><div className="flex-1"><div className="flex justify-between gap-2"><span className="font-semibold text-sm">{i.type}</span><span className={`px-2 py-0.5 rounded-full border text-[10px] ${priorityClass(i.priority)}`}>{i.priority}</span></div><div className="text-xs text-slate-500 mt-1">{i.location} · {i.reason}</div></div></div></button>)}</div>
    </div>
    <div className="card p-5"><h3 className="font-bold">AI situation summary</h3><p className="text-sm text-slate-300 mt-3 leading-6">{data.length?`${data.length} active incidents have been reported. ${critical} are classified as critical. ${sorted[0]?.location||"No area"} currently has the highest estimated priority.`:"No reports yet. Launch the demo to see the situation summary."}</p>
      <div className="grid grid-cols-2 gap-3 mt-4">{[["Highest risk",sorted[0]?.location||"—"],["Most common",mostCommon(data)||"—"],["Affected",affected||0],["Infrastructure",data.filter(x=>/damage|blockage|landslide/i.test(x.type)).length]].map(([a,b])=><div key={a} className="rounded-lg bg-black/20 p-3"><div className="text-[10px] uppercase text-slate-600">{a}</div><div className="font-semibold text-sm mt-1">{b}</div></div>)}</div>
    </div>
   </div>
  </div>
  <div className="grid lg:grid-cols-2 gap-5 mt-5">
   <div className="card p-5"><div className="flex items-center justify-between"><h3 className="font-bold">Resource allocation</h3><Package size={18} className="text-teal-300"/></div><div className="grid sm:grid-cols-2 gap-3 mt-4">{resources.map((r:any,idx:number)=><div key={r[0]} className="rounded-xl border border-white/5 bg-white/[.025] p-4"><div className="flex justify-between"><span className="text-sm">{r[0]}</span><span className="font-black">{r[1]}</span></div><div className="h-1.5 bg-white/5 rounded-full mt-3 overflow-hidden"><div className="h-full bg-teal-300/70 rounded-full" style={{width:`${Math.min(100,Number(r[1])/8)}%`}}/></div><div className="text-[11px] text-slate-500 mt-2">{r[2]}</div><button onClick={()=>{const c=[...resources];c[idx]=[r[0],Math.max(0,r[1]-1),`${Number(r[1])-1} remaining · 1 newly assigned`];setResources(c)}} className="mt-3 text-xs text-teal-300 hover:underline">Assign 1 →</button></div>)}</div></div>
   <div className="card p-5"><h3 className="font-bold">Verification & incident timeline</h3>{selected?<div className="mt-4"><div className="flex items-center justify-between"><div><div className="font-semibold">{selected.id} · {selected.type}</div><div className="text-xs text-slate-500">{selected.location}</div></div><span className={`px-2 py-1 rounded-full border text-[10px] ${selected.confidence>=85?"text-emerald-300 border-emerald-400/20":"text-yellow-200 border-yellow-400/20"}`}>{selected.confidence>=85?"● Verified":"● Needs verification"}</span></div><div className="mt-4 space-y-3">{["Report submitted","AI analysis completed","Priority assigned","Response team assigned","Incident updated"].map((x,n)=><div className="flex gap-3 text-sm" key={x}><div className="mt-1 h-2 w-2 rounded-full bg-teal-300"/><div><div className="text-slate-300">{x}</div><div className="text-[11px] text-slate-600">{["10:42 PM","10:43 PM","10:44 PM","10:48 PM","11:02 PM"][n]}</div></div></div>)}</div></div>:<div className="mt-4 p-5 rounded-xl bg-white/[.03] text-sm text-slate-500">Select an incident marker or ranking to inspect verification status and timeline.</div>}</div>
  </div>
  {selected&&<div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm p-4 flex items-end sm:items-center justify-center" onClick={()=>setSelected(null)}><div className="card w-full max-w-xl p-6" onClick={e=>e.stopPropagation()}><div className="flex justify-between"><div><div className="text-xs text-teal-300 font-mono">{selected.id}</div><h3 className="text-2xl font-black mt-1">{selected.type}</h3><div className="text-sm text-slate-500 flex items-center gap-1 mt-1"><MapPin size={14}/>{selected.location}</div></div><button onClick={()=>setSelected(null)} className="p-2 hover:bg-white/5 rounded-lg"><X size={18}/></button></div><div className="grid grid-cols-2 gap-3 mt-6"><div className="rounded-xl bg-red-400/5 border border-red-400/10 p-4"><div className="text-xs text-slate-500">Priority</div><div className="text-4xl font-black text-red-300 mt-1">{selected.priority}<span className="text-sm text-slate-600">/100</span></div><div className="text-xs mt-1">{priorityLabel(selected.priority)}</div></div><div className="rounded-xl bg-white/[.03] p-4"><div className="text-xs text-slate-500">People affected</div><div className="text-3xl font-black mt-2">{selected.affected}</div><div className="text-xs text-slate-500 mt-1">Report confidence {selected.confidence}%</div></div></div><div className="mt-5"><div className="text-xs uppercase tracking-widest text-slate-500">AI reasoning</div><p className="mt-2 text-sm text-slate-300 leading-6">{selected.reason}</p></div><div className="mt-5 flex items-center justify-between rounded-xl border border-white/5 bg-white/[.025] p-4 text-sm"><span>Status</span><span className="text-teal-300">{selected.status}</span></div><div className="mt-4 text-[11px] text-slate-600">Decision-support recommendation. Final prioritization should be reviewed by trained emergency personnel.</div></div></div>}
 </section>
}

function mostCommon(data:Incident[]){const c:any={};data.forEach(x=>c[x.type]=(c[x.type]||0)+1);return Object.entries(c).sort((a:any,b:any)=>b[1]-a[1])[0]?.[0]}

function How(){
 const steps=[["Community reports","Structured reports, optional media, location and impact.","Users"],["AI analysis","Severity, impact, danger, infrastructure, access and confidence are scored.","Decision engine"],["Priority score","A transparent 0–100 score and category are generated.","Ranking"],["Map visualization","Incidents become spatially visible and selectable.","Operations map"],["Resource allocation","Teams, boats, ambulances and supplies can be assigned.","Coordination"],["Emergency response","Human responders review recommendations and act.","Human-in-the-loop"]];
 return <section className="max-w-6xl mx-auto px-5 pt-12"><div className="max-w-3xl"><div className="text-xs uppercase tracking-[.2em] text-teal-300">Judge view</div><h2 className="text-5xl font-black mt-2">How DisasterLens works</h2><p className="mt-4 text-slate-400 text-lg">A clear pipeline from unstructured community signals to a prioritized operational picture.</p></div><div className="mt-10 grid md:grid-cols-2 lg:grid-cols-3 gap-4">{steps.map(([a,b,c],i)=><div className="card p-6 relative" key={a}><div className="text-4xl font-black text-white/10 absolute right-5 top-4">0{i+1}</div><div className="text-xs text-teal-300">{c}</div><h3 className="font-bold text-lg mt-5">{a}</h3><p className="text-sm text-slate-400 leading-6 mt-2">{b}</p></div>)}</div><div className="card mt-6 p-6"><div className="flex gap-3"><ShieldCheck className="text-teal-300 shrink-0"/><div><h3 className="font-bold">Responsible AI boundary</h3><p className="text-sm text-slate-400 mt-2 leading-6">DisasterLens is designed as decision support, not an autonomous emergency authority. Scores are simulated in this hackathon build and should not be treated as guaranteed predictions, safety assessments, or rescue instructions.</p></div></div></div></section>
}